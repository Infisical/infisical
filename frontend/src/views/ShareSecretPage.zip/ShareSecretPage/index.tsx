export { ShareSecretPage } from "./ShareSecretPage";
