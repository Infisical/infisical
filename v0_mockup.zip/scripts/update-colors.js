const { readFileSync, writeFileSync, readdirSync, statSync } = require('fs');
const { join, resolve } = require('path');

const root = '/vercel/share/v0-project';

const colorMap = {
  '#0E1014': '#0d0f11',
  '#161B22': '#1a1d21',
  '#21262D': '#2e3238',
  '#30363D': '#3b3f47',
  '#484F58': '#4b4f58',
  '#6E7681': '#5c6170',
  '#8B949E': '#7c8189',
  '#E6EDF3': '#e2e8f0',
  '#3FB950': '#68d391',
  '#F85149': '#fc8181',
  '#D29922': '#ecc94b',
  '#388BFD': '#63b3ed',
  '#58A6FF': '#90cdf4',
  '#DA3633': '#e53e3e',
  '#1C2128': '#1e2127',
};

function processFile(filePath) {
  let content = readFileSync(filePath, 'utf-8');
  let changed = false;
  for (const [oldColor, newColor] of Object.entries(colorMap)) {
    if (content.includes(oldColor)) {
      content = content.replaceAll(oldColor, newColor);
      changed = true;
    }
  }
  if (changed) {
    writeFileSync(filePath, content);
    console.log('Updated: ' + filePath);
  }
}

function walk(dir) {
  let entries;
  try {
    entries = readdirSync(dir);
  } catch (e) {
    console.log('Skipping dir: ' + dir + ' (' + e.message + ')');
    return;
  }
  for (const entry of entries) {
    const full = join(dir, entry);
    if (entry === 'node_modules' || entry === '.next') continue;
    const stat = statSync(full);
    if (stat.isDirectory()) walk(full);
    else if (full.endsWith('.tsx') || full.endsWith('.ts') || full.endsWith('.css')) {
      processFile(full);
    }
  }
}

console.log('Root: ' + root);
walk(join(root, 'app'));
walk(join(root, 'components'));
console.log('Done!');
