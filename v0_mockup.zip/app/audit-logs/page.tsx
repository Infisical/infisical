"use client"

import { useState } from "react"
import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import { Search, Download, ChevronRight, Info, Lock } from "lucide-react"

const timeRanges = ["5m", "30m", "1h", "3h", "12h", "24h", "7d", "Custom"] as const

const auditLogs = [
  {
    id: 1,
    timestamp: "Feb 24th 2026, 11:50 PM",
    event: "policy-activated",
    actor: "user",
    details: 'user_email: ashwin@infisical.com  policy: "PQC Unsafe Protocols"',
    expanded: false,
  },
  {
    id: 2,
    timestamp: "Feb 24th 2026, 11:49 PM",
    event: "discovery-scan-completed",
    actor: "system",
    details: 'job: "prod-network-scan"  assets_found: 1247  duration: "4m 32s"',
    expanded: false,
  },
  {
    id: 3,
    timestamp: "Feb 24th 2026, 11:48 PM",
    event: "violation-accepted-risk",
    actor: "user",
    details: 'user_email: daniel@infisical.com  violation_id: viol_8kxp2  policy: "Small RSA Key Length"',
    expanded: false,
  },
  {
    id: 4,
    timestamp: "Feb 24th 2026, 11:45 PM",
    event: "policy-created",
    actor: "user",
    details: 'user_email: arsh@infisical.com  policy: "Minimum ECC Key Size"  type: "user-defined"',
    expanded: false,
  },
  {
    id: 5,
    timestamp: "Feb 24th 2026, 11:40 PM",
    event: "integration-added",
    actor: "user",
    details: 'user_email: ashwin@infisical.com  integration: "Jira Cloud"  project: "INFRA"',
    expanded: false,
  },
  {
    id: 6,
    timestamp: "Feb 24th 2026, 11:30 PM",
    event: "discovery-scan-started",
    actor: "user",
    details: 'user_email: ashwin@infisical.com  job: "k8s-cluster-prod"',
    expanded: false,
  },
  {
    id: 7,
    timestamp: "Feb 24th 2026, 11:20 PM",
    event: "violation-ticket-created",
    actor: "system",
    details: 'violation_id: viol_9mxq1  ticket: "INFRA-2847"  system: "Jira"',
    expanded: false,
  },
  {
    id: 8,
    timestamp: "Feb 24th 2026, 10:15 PM",
    event: "policy-deactivated",
    actor: "user",
    details: 'user_email: carlos@infisical.com  policy: "Organization Default PQC Baseline"',
    expanded: false,
  },
  {
    id: 9,
    timestamp: "Feb 24th 2026, 09:30 PM",
    event: "nexus-settings-updated",
    actor: "user",
    details: 'user_email: ashwin@infisical.com  setting: "retention_days"  value: "365"',
    expanded: false,
  },
  {
    id: 10,
    timestamp: "Feb 24th 2026, 08:00 PM",
    event: "discovery-scan-completed",
    actor: "system",
    details: 'job: "k8s-cluster-prod"  assets_found: 384  duration: "2m 15s"',
    expanded: false,
  },
]

function EventTag({ event }: { event: string }) {
  return (
    <span className="rounded bg-[#2e3238] px-2 py-0.5 font-mono text-[11px] text-[#e2e8f0]">
      {event}
    </span>
  )
}

function ActorTag({ actor }: { actor: string }) {
  return (
    <span className="rounded bg-[#2e3238] px-1.5 py-0.5 text-[10px] font-medium text-[#7c8189]">
      {actor}
    </span>
  )
}

export default function AuditLogsPage() {
  const [activeRange, setActiveRange] = useState("7d")
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set())

  const toggleRow = (id: number) => {
    setExpandedRows((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <NexusLayout>
      <PageHeader
        title="Audit Logs"
        description="Immutable audit trail of all Nexus actions for compliance and security investigations."
        docLink="audit-logs"
      />

      {/* Compliance note */}
      <div className="mb-5 rounded-lg border border-[#2e3238] bg-[#1a1d21] p-4">
        <div className="flex items-start gap-2">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#4b4f58]" />
          <div className="text-xs leading-relaxed text-[#7c8189]">
            <p>
              Nexus audit logs are immutable and retained for 365 days by default. These logs satisfy PCI DSS cryptographic inventory audit requirements and DORA operational resilience reporting obligations.
            </p>
            <div className="mt-2 flex items-center gap-1.5">
              <Lock className="h-3 w-3 text-[#ecc94b]" />
              <span className="rounded border border-[#ecc94b]/30 bg-[#ecc94b]/10 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-[#ecc94b]">
                ENTERPRISE
              </span>
              <span className="text-[11px] text-[#7c8189]">Extended retention and custom export schedules available in Enterprise plan.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Time range toggle */}
          <div className="flex rounded-md border border-[#2e3238] bg-[#111317]">
            {timeRanges.map((range) => (
              <button
                key={range}
                onClick={() => setActiveRange(range)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors ${
                  activeRange === range
                    ? "bg-[#1a1d21] text-[#e2e8f0]"
                    : "text-[#7c8189] hover:text-[#e2e8f0]"
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          {/* Timezone */}
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
            <option>Local Timezone</option>
            <option>UTC</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5">
            <Search className="mr-2 h-3.5 w-3.5 text-[#5c6170]" />
            <input
              type="text"
              placeholder="Search audit logs..."
              className="w-48 bg-transparent text-xs text-[#e2e8f0] placeholder-[#5c6170] outline-none"
            />
          </div>
          <button className="flex items-center gap-1.5 rounded-md border border-[#2e3238] px-3 py-1.5 text-xs text-[#7c8189] hover:bg-[#1a1d21]">
            <Download className="h-3.5 w-3.5" />
            Export
          </button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="mb-4 flex items-center gap-2">
        <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
          <option>All Events</option>
          <option>Policy Events</option>
          <option>Discovery Events</option>
          <option>Violation Events</option>
          <option>Integration Events</option>
          <option>User Access Events</option>
        </select>
        <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
          <option>All Users</option>
          <option>ashwin@infisical.com</option>
          <option>daniel@infisical.com</option>
          <option>arsh@infisical.com</option>
        </select>
        <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
          <option>All Status</option>
          <option>Success</option>
          <option>Failed</option>
        </select>
      </div>

      {/* Audit History */}
      <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21]">
        <div className="border-b border-[#2e3238] bg-[#111317] px-4 py-3">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-[#7c8189]">
            Audit History
          </h2>
        </div>

        <table className="w-full">
          <thead>
            <tr className="border-b border-[#2e3238] bg-[#111317]">
              <th className="w-8 px-3 py-2" />
              {["#", "TIMESTAMP", "ACTOR", "EVENT", "DETAILS"].map((h) => (
                <th key={h} className="px-3 py-2 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {auditLogs.map((log) => (
              <>
                <tr
                  key={log.id}
                  className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]"
                  onClick={() => toggleRow(log.id)}
                >
                  <td className="px-3 py-3">
                    <ChevronRight
                      className={`h-3.5 w-3.5 text-[#7c8189] transition-transform ${
                        expandedRows.has(log.id) ? "rotate-90" : ""
                      }`}
                    />
                  </td>
                  <td className="px-3 py-3 text-xs text-[#5c6170]">{log.id}</td>
                  <td className="px-3 py-3 text-xs text-[#7c8189]">{log.timestamp}</td>
                  <td className="px-3 py-3"><ActorTag actor={log.actor} /></td>
                  <td className="px-3 py-3"><EventTag event={log.event} /></td>
                  <td className="px-3 py-3">
                    <span className="font-mono text-[11px] text-[#7c8189]">{log.details}</span>
                  </td>
                </tr>
                {expandedRows.has(log.id) && (
                  <tr key={`${log.id}-expanded`} className="border-b border-[#2e3238] bg-[#111317]">
                    <td colSpan={6} className="px-10 py-4">
                      <pre className="overflow-x-auto rounded-md border border-[#2e3238] bg-[#1a1d21] p-4 font-mono text-[11px] text-[#7c8189]">
{`{
  "event": "${log.event}",
  "actor": "${log.actor}",
  "timestamp": "${log.timestamp}",
  ${log.details.split("  ").map(d => {
    const [key, val] = d.split(": ")
    return `"${key?.trim()}": ${val?.trim()}`
  }).join(",\n  ")}
}`}
                      </pre>
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>

      {/* Load more */}
      <div className="mt-4 flex justify-center">
        <button className="rounded-md border border-[#2e3238] px-6 py-2 text-xs font-medium text-[#7c8189] transition-colors hover:bg-[#1a1d21] hover:text-[#e2e8f0]">
          Load More (10 loaded)
        </button>
      </div>
    </NexusLayout>
  )
}
