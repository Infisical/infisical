"use client"

import { useState } from "react"
import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import {
  Search,
  Filter,
  Download,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react"

const tabs = ["Endpoints", "Keys", "Certificates", "Protocols"] as const
type Tab = (typeof tabs)[number]

const endpointData = [
  { scanId: "SCN-0041", country: "US", host: "10.0.1.15", port: 443, protocol: "TLS", version: "1.3", cipher: "TLS_AES_256_GCM_SHA384", strength: "HIGH" },
  { scanId: "SCN-0042", country: "US", host: "10.0.1.22", port: 443, protocol: "TLS", version: "1.2", cipher: "ECDHE-RSA-AES128-GCM-SHA256", strength: "MEDIUM" },
  { scanId: "SCN-0043", country: "DE", host: "172.16.3.8", port: 8443, protocol: "TLS", version: "1.3", cipher: "TLS_CHACHA20_POLY1305_SHA256", strength: "HIGH" },
  { scanId: "SCN-0044", country: "GB", host: "192.168.1.50", port: 443, protocol: "TLS", version: "1.0", cipher: "DHE-RSA-AES128-SHA", strength: "LOW" },
  { scanId: "SCN-0045", country: "US", host: "10.0.2.100", port: 443, protocol: "TLS", version: "1.2", cipher: "ECDHE-ECDSA-AES256-GCM-SHA384", strength: "HIGH" },
  { scanId: "SCN-0046", country: "JP", host: "10.0.5.33", port: 443, protocol: "SSL", version: "3.0", cipher: "RC4-SHA", strength: "LOW" },
  { scanId: "SCN-0047", country: "US", host: "172.16.0.12", port: 8443, protocol: "TLS", version: "1.3", cipher: "TLS_AES_128_GCM_SHA256", strength: "HIGH" },
  { scanId: "SCN-0048", country: "FR", host: "10.0.3.77", port: 443, protocol: "TLS", version: "1.2", cipher: "AES256-GCM-SHA384", strength: "MEDIUM" },
  { scanId: "SCN-0049", country: "IN", host: "10.0.4.91", port: 8080, protocol: "TLS", version: "1.0", cipher: "DES-CBC3-SHA", strength: "LOW", expiredCert: true },
]

const keysData = [
  { keyId: "key-a1b2c3", project: "Secrets-Prod", type: "Asymmetric", algo: "RSA", length: 2048, pqcSafe: false, created: "Jan 15, 2025", expires: "Jan 15, 2027", violations: 3 },
  { keyId: "key-d4e5f6", project: "KMS_TEST", type: "Asymmetric", algo: "ML-KEM-768", length: 768, pqcSafe: true, created: "Feb 01, 2026", expires: "Feb 01, 2028", violations: 0 },
  { keyId: "key-g7h8i9", project: "Secrets-Staging", type: "Symmetric", algo: "AES", length: 256, pqcSafe: true, created: "Mar 10, 2025", expires: "Mar 10, 2027", violations: 0 },
  { keyId: "key-j1k2l3", project: "KMS_TEST", type: "Asymmetric", algo: "ECDSA", length: 256, pqcSafe: false, created: "Jun 20, 2024", expires: "Jun 20, 2026", violations: 2 },
  { keyId: "key-m4n5o6", project: "Secrets-Prod", type: "Symmetric", algo: "AES", length: 128, pqcSafe: false, created: "Aug 05, 2024", expires: "Aug 05, 2026", violations: 1 },
  { keyId: "key-p7q8r9", project: "KMS_TEST", type: "Asymmetric", algo: "RSA", length: 4096, pqcSafe: false, created: "Dec 12, 2024", expires: "Dec 12, 2026", violations: 1 },
]

const certsData = [
  { cn: "*.acmecorp.com", serial: "3A:F2:1B:9C:04:D8", source: "Managed", status: "Healthy", issued: "Jan 10, 2026", expires: "Jan 10, 2027", algo: "ECDSA-256", pqcSafe: false, violations: 0 },
  { cn: "api.acmecorp.com", serial: "7B:E4:2C:A1:08:F3", source: "Discovered", status: "Expired", issued: "Nov 01, 2024", expires: "Nov 01, 2025", algo: "RSA-2048", pqcSafe: false, violations: 2 },
  { cn: "db.internal.corp", serial: "1D:C8:3E:B5:0A:27", source: "Imported", status: "Expiring Soon", issued: "Aug 15, 2025", expires: "Mar 02, 2026", algo: "RSA-2048", pqcSafe: false, violations: 1 },
  { cn: "mail.acmecorp.com", serial: "9F:A6:4D:C2:0E:19", source: "Managed", status: "Healthy", issued: "Feb 20, 2026", expires: "Feb 20, 2027", algo: "Ed25519", pqcSafe: true, violations: 0 },
  { cn: "vault.acmecorp.com", serial: "5E:B1:7A:D9:02:84", source: "Discovered", status: "Revoked", issued: "Sep 05, 2024", expires: "Sep 05, 2025", algo: "RSA-4096", pqcSafe: false, violations: 1 },
  { cn: "cdn.acmecorp.com", serial: "2C:D7:8F:E4:06:B5", source: "Managed", status: "Healthy", issued: "Dec 01, 2025", expires: "Dec 01, 2026", algo: "ECDSA-384", pqcSafe: false, violations: 0 },
]

const protocolsData = [
  { host: "10.0.1.15", port: 443, protocol: "TLS", version: "1.3", cipher: "TLS_AES_256_GCM_SHA384", strength: "HIGH", itAsset: "Web Server Prod", lastScanned: "Feb 24, 2026" },
  { host: "10.0.1.22", port: 443, protocol: "TLS", version: "1.2", cipher: "ECDHE-RSA-AES128-GCM-SHA256", strength: "MEDIUM", itAsset: "API Gateway", lastScanned: "Feb 24, 2026" },
  { host: "172.16.3.8", port: 8443, protocol: "TLS", version: "1.3", cipher: "TLS_CHACHA20_POLY1305_SHA256", strength: "HIGH", itAsset: "Database Cluster", lastScanned: "Feb 23, 2026" },
  { host: "192.168.1.50", port: 443, protocol: "TLS", version: "1.0", cipher: "DHE-RSA-AES128-SHA", strength: "LOW", itAsset: "Legacy App", lastScanned: "Feb 22, 2026" },
  { host: "10.0.5.33", port: 443, protocol: "SSL", version: "3.0", cipher: "RC4-SHA", strength: "LOW", itAsset: "Staging Server", lastScanned: "Feb 24, 2026" },
]

function StrengthBadge({ strength }: { strength: string }) {
  const colors: Record<string, string> = {
    HIGH: "#68d391",
    MEDIUM: "#ecc94b",
    LOW: "#fc8181",
  }
  return (
    <span className="text-[11px]" style={{ color: colors[strength] || "#7c8189" }}>
      {strength}
    </span>
  )
}

function VersionBadge({ version }: { version: string }) {
  const color =
    version === "1.3" ? "#68d391" : version === "1.2" ? "#ecc94b" : "#fc8181"
  return <span style={{ color }} className="font-mono text-xs">{version}</span>
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    Healthy: "#68d391",
    Expired: "#fc8181",
    "Expiring Soon": "#ecc94b",
    Revoked: "#fc8181",
  }
  return (
    <span className="text-[11px]" style={{ color: colors[status] || "#7c8189" }}>
      {status}
    </span>
  )
}

// Drawer component for asset detail
function AssetDrawer({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-y-0 right-0 z-50 flex w-[420px] flex-col border-l border-[#2e3238] bg-[#1a1d21] shadow-2xl">
      <div className="flex items-center justify-between border-b border-[#2e3238] px-5 py-4">
        <div>
          <h3 className="text-sm font-semibold text-[#e2e8f0]">10.0.1.15</h3>
          <span className="rounded bg-[#2e3238] px-1.5 py-0.5 text-[10px] text-[#7c8189]">
            Endpoint
          </span>
        </div>
        <button onClick={onClose} className="rounded p-1 text-[#7c8189] hover:bg-[#1a1d21] hover:text-[#e2e8f0]">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-5">
        {/* Overview Section */}
        <div className="mb-5">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Overview</h4>
          <div className="flex flex-col gap-2 text-xs">
            {[
              ["Host", "10.0.1.15"],
              ["Port", "443"],
              ["Protocol", "TLS 1.3"],
              ["Cipher Suite", "TLS_AES_256_GCM_SHA384"],
              ["Strength", "HIGH"],
              ["Country", "US"],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between">
                <span className="text-[#7c8189]">{label}</span>
                <span className="font-mono text-[#e2e8f0]">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Linked IT Asset */}
        <div className="mb-5 border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Linked IT Asset</h4>
          <span className="cursor-pointer text-sm text-[#63b3ed] hover:underline">Web Server Prod</span>
          <span className="ml-2 text-xs text-[#7c8189]">(Service)</span>
        </div>

        {/* PQC Status */}
        <div className="mb-5 border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">PQC Status</h4>
          <span className="text-xs text-[#68d391]">Safe</span>
          <p className="mt-2 text-xs text-[#7c8189]">
            TLS 1.3 with AES-256-GCM provides quantum-resistant symmetric encryption.
          </p>
        </div>

        {/* Policy Violations */}
        <div className="mb-5 border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Policy Violations</h4>
          <p className="text-xs text-[#68d391]">No violations</p>
        </div>

        {/* Remediation */}
        <div className="border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Remediation</h4>
          <p className="text-xs text-[#7c8189]">No action needed. This endpoint is using PQC-safe configurations.</p>
        </div>
      </div>

      {/* Footer */}
      <div className="flex gap-2 border-t border-[#2e3238] px-5 py-3">
        <button className="flex-1 rounded-md border border-[#3b3f47] bg-transparent px-3 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
          Create Ticket
        </button>
        <button className="rounded-md border border-[#2e3238] px-3 py-2 text-xs text-[#e2e8f0] hover:bg-[#1a1d21]">
          View Source
        </button>
        <button className="rounded-md border border-[#2e3238] px-3 py-2 text-xs text-[#e2e8f0] hover:bg-[#1a1d21]">
          Export
        </button>
      </div>
    </div>
  )
}

export default function CryptographicAssetsPage() {
  const [activeTab, setActiveTab] = useState<Tab>("Endpoints")
  const [drawerOpen, setDrawerOpen] = useState(false)

  return (
    <NexusLayout>
      <PageHeader
        title="Cryptographic Assets"
        description="Complete inventory of cryptographic objects discovered across your organization."
        docLink="cryptographic-assets"
      />

      {/* Tab bar */}
      <div className="mb-4 flex items-center border-b border-[#2e3238]">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2.5 text-sm font-medium transition-colors ${
              activeTab === tab
                ? "border-b-2 border-[#e2e8f0] text-[#e2e8f0]"
                : "text-[#7c8189] hover:text-[#e2e8f0]"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5">
            <Search className="mr-2 h-3.5 w-3.5 text-[#5c6170]" />
            <input
              type="text"
              placeholder="Search by host, key ID, CN, algorithm..."
              className="w-64 bg-transparent text-xs text-[#e2e8f0] placeholder-[#5c6170] outline-none"
            />
          </div>
          <button className="flex items-center gap-1.5 rounded-md border border-[#2e3238] px-3 py-1.5 text-xs text-[#7c8189] hover:bg-[#1a1d21] hover:text-[#e2e8f0]">
            <Filter className="h-3.5 w-3.5" />
            Filter
          </button>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 rounded-md border border-[#2e3238] px-3 py-1.5 text-xs text-[#7c8189] hover:bg-[#1a1d21] hover:text-[#e2e8f0]">
            <Download className="h-3.5 w-3.5" />
            Export CSV
          </button>
          <button className="flex items-center gap-1.5 rounded-md border border-[#2e3238] px-3 py-1.5 text-xs text-[#7c8189] hover:bg-[#1a1d21] hover:text-[#e2e8f0]">
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21]">
        {activeTab === "Endpoints" && (
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2e3238] bg-[#111317]">
                {["SCAN ID", "COUNTRY", "HOST", "PORT", "PROTOCOL", "VERSION", "CIPHER SUITE", "STRENGTH", "FLAGS"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {endpointData.map((row, i) => (
                <tr
                  key={i}
                  className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]"
                  onClick={() => setDrawerOpen(true)}
                >
                  <td className="px-4 py-3 font-mono text-xs text-[#e2e8f0]">{row.scanId}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.country}</td>
                  <td className="px-4 py-3 font-mono text-xs text-[#e2e8f0]">{row.host}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.port}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.protocol}</td>
                  <td className="px-4 py-3"><VersionBadge version={row.version} /></td>
                  <td className="px-4 py-3 font-mono text-xs text-[#7c8189]">{row.cipher}</td>
                  <td className="px-4 py-3"><StrengthBadge strength={row.strength} /></td>
                  <td className="px-4 py-3">
                    {"expiredCert" in row && row.expiredCert ? (
                      <div className="flex gap-1">
                        <span className="rounded bg-[#fc8181]/15 px-1.5 py-0.5 text-[10px] font-medium text-[#fc8181]">Expired Cert</span>
                        <span className="rounded bg-[#fc8181]/15 px-1.5 py-0.5 text-[10px] font-medium text-[#fc8181]">Weak Protocol</span>
                      </div>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {activeTab === "Keys" && (
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2e3238] bg-[#111317]">
                {["KEY ID", "SOURCE PROJECT", "TYPE", "ALGORITHM", "KEY LENGTH", "PQC SAFE?", "CREATED", "EXPIRES", "VIOLATIONS"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {keysData.map((row, i) => (
                <tr key={i} className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]" onClick={() => setDrawerOpen(true)}>
                  <td className="px-4 py-3 font-mono text-xs text-[#e2e8f0]">{row.keyId}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.project}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.type}</td>
                  <td className="px-4 py-3 text-xs text-[#e2e8f0]">{row.algo}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.length}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[11px] ${row.pqcSafe ? "text-[#68d391]" : "text-[#fc8181]"}`}>
                      {row.pqcSafe ? "Safe" : "Unsafe"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-[#4b4f58]">{row.created}</td>
                  <td className="px-4 py-3 text-xs text-[#4b4f58]">{row.expires}</td>
                  <td className="px-4 py-3">
                    {row.violations > 0 ? (
                      <span className="text-xs text-[#7c8189]">{row.violations}</span>
                    ) : (
                      <span className="text-xs text-[#4b4f58]">0</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {activeTab === "Certificates" && (
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2e3238] bg-[#111317]">
                {["CN / SAN", "SERIAL NUMBER", "SOURCE", "STATUS", "ISSUED AT", "EXPIRING AT", "ALGORITHM", "PQC SAFE?", "VIOLATIONS"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {certsData.map((row, i) => (
                <tr key={i} className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]" onClick={() => setDrawerOpen(true)}>
                  <td className="px-4 py-3 text-xs text-[#e2e8f0]">{row.cn}</td>
                  <td className="px-4 py-3 font-mono text-[11px] text-[#7c8189]">{row.serial}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.source}</td>
                  <td className="px-4 py-3"><StatusBadge status={row.status} /></td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.issued}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.expires}</td>
                  <td className="px-4 py-3 text-xs text-[#e2e8f0]">{row.algo}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[11px] ${row.pqcSafe ? "text-[#68d391]" : "text-[#fc8181]"}`}>
                      {row.pqcSafe ? "Safe" : "Unsafe"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {row.violations > 0 ? (
                      <span className="text-xs text-[#7c8189]">{row.violations}</span>
                    ) : (
                      <span className="text-xs text-[#4b4f58]">0</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {activeTab === "Protocols" && (
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2e3238] bg-[#111317]">
                {["HOST", "PORT", "PROTOCOL", "VERSION", "CIPHER SUITE", "STRENGTH", "IT ASSET", "LAST SCANNED"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {protocolsData.map((row, i) => (
                <tr key={i} className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]" onClick={() => setDrawerOpen(true)}>
                  <td className="px-4 py-3 font-mono text-xs text-[#e2e8f0]">{row.host}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.port}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.protocol}</td>
                  <td className="px-4 py-3"><VersionBadge version={row.version} /></td>
                  <td className="px-4 py-3 font-mono text-xs text-[#7c8189]">{row.cipher}</td>
                  <td className="px-4 py-3"><StrengthBadge strength={row.strength} /></td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.itAsset}</td>
                  <td className="px-4 py-3 text-xs text-[#7c8189]">{row.lastScanned}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Footer pagination */}
      <div className="mt-4 flex items-center justify-between text-xs text-[#7c8189]">
        <span>Total rows: 84,200</span>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span>Items per page:</span>
            <select className="rounded border border-[#2e3238] bg-[#111317] px-2 py-1 text-xs text-[#e2e8f0] outline-none">
              <option>20</option>
              <option>50</option>
              <option>100</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <button className="rounded p-1 hover:bg-[#1a1d21]">
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-[#e2e8f0]">1 of 4,210</span>
            <button className="rounded p-1 hover:bg-[#1a1d21]">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Drawer */}
      {drawerOpen && <AssetDrawer onClose={() => setDrawerOpen(false)} />}
    </NexusLayout>
  )
}
