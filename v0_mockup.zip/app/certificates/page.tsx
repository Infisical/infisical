"use client"

import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const certStatusDonut = [
  { name: "Expired", value: 365, fill: "#fc8181" },
  { name: "Revoked", value: 242, fill: "#ecc94b" },
  { name: "Not-yet-valid", value: 195, fill: "#5c6170" },
  { name: "Valid", value: 499, fill: "#68d391" },
]

const caDonut = [
  { name: "Internal CA", value: 520, fill: "#63b3ed" },
  { name: "Let's Encrypt", value: 380, fill: "#68d391" },
  { name: "DigiCert", value: 245, fill: "#90cdf4" },
  { name: "Sectigo", value: 98, fill: "#ecc94b" },
  { name: "Other", value: 58, fill: "#5c6170" },
]

const sigAlgoDonut = [
  { name: "RSA-2048", value: 472, fill: "#fc8181" },
  { name: "ECDSA-256", value: 238, fill: "#ecc94b" },
  { name: "RSA-4096", value: 87, fill: "#ecc94b" },
  { name: "Ed25519", value: 68, fill: "#68d391" },
  { name: "Other", value: 436, fill: "#5c6170" },
]

const policyViolations = [
  { name: "Certificate Validity Period Check", count: 61 },
  { name: "Small RSA Key Length", count: 59 },
  { name: "Weak Signature Algorithm", count: 6 },
]

const expiringRanges = [
  { range: "< 10 days", count: 4 },
  { range: "11-20 days", count: 12 },
  { range: "21-30 days", count: 10 },
  { range: "31-40 days", count: 28 },
  { range: "41-50 days", count: 35 },
]

function DonutChart({
  data,
  centerLabel,
}: {
  data: { name: string; value: number; fill: string }[]
  centerLabel: string
}) {
  return (
    <div className="relative h-[120px] w-[120px]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={35}
            outerRadius={55}
            dataKey="value"
            strokeWidth={0}
          >
            {data.map((entry, index) => (
              <Cell key={index} fill={entry.fill} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <span className="absolute inset-0 flex items-center justify-center text-sm font-semibold text-[#e2e8f0]">
        {centerLabel}
      </span>
    </div>
  )
}

export default function CertificatesPage() {
  return (
    <NexusLayout>
      <PageHeader
        title="Certificates"
        description="Monitor certificate health, expiry, PQC readiness, and policy compliance across your estate."
        docLink="certificates"
      />

      {/* Top Strip - Certificate PQC Readiness */}
      <div className="mb-6 rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
        <div className="flex items-center gap-6">
          <svg width="120" height="75" viewBox="0 0 120 75">
            <path
              d="M 10 65 A 50 50 0 0 1 110 65"
              fill="none"
              stroke="#2e3238"
              strokeWidth="8"
              strokeLinecap="round"
            />
            <path
              d="M 10 65 A 50 50 0 0 1 28 24"
              fill="none"
              stroke="#fc8181"
              strokeWidth="8"
              strokeLinecap="round"
            />
            <text x="60" y="52" textAnchor="middle" fill="#e2e8f0" fontSize="16" fontWeight="600">
              15.2%
            </text>
            <text x="60" y="67" textAnchor="middle" fill="#4b4f58" fontSize="9">
              Certificate PQC
            </text>
          </svg>

          <div className="flex gap-6">
            <div className="text-center">
              <p className="text-xl font-semibold text-[#fc8181]">1,063</p>
              <p className="text-xs text-[#4b4f58]">Unsafe</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-semibold text-[#68d391]">182</p>
              <p className="text-xs text-[#4b4f58]">Safe</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-semibold text-[#5c6170]">56</p>
              <p className="text-xs text-[#4b4f58]">Not Evaluated</p>
            </div>
          </div>
        </div>
      </div>

      {/* Row 1 - Two columns */}
      <div className="mb-6 grid grid-cols-2 gap-4">
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <div className="mb-1 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-[#e2e8f0]">Total Certificates</h2>
            <span className="cursor-pointer text-xs text-[#7c8189] hover:text-[#e2e8f0]">View all (1,301)</span>
          </div>
          <p className="mb-4 text-2xl font-semibold text-[#e2e8f0]">1,301</p>
          <div className="flex items-center gap-6">
            <DonutChart data={certStatusDonut} centerLabel="1,301" />
            <div className="flex flex-col gap-2 text-[11px]">
              {certStatusDonut.map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.fill }} />
                  <span className="text-[#4b4f58]">{item.name}: <span className="text-[#7c8189]">{item.value}</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <div className="mb-1 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-[#e2e8f0]">Policy Violations on Certificates</h2>
            <span className="cursor-pointer text-xs text-[#7c8189] hover:text-[#e2e8f0]">View all (126)</span>
          </div>
          <p className="mb-4 text-2xl font-semibold text-[#e2e8f0]">126</p>
          <div className="flex flex-col">
            {policyViolations.map((v, i) => (
              <div key={i} className="flex items-center justify-between border-b border-[#2e3238] py-3 last:border-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#4b4f58]">{i + 1}.</span>
                  <span className="text-[13px] text-[#e2e8f0]">{v.name}</span>
                </div>
                <span className="text-sm text-[#7c8189]">{v.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 2 - Three columns */}
      <div className="grid grid-cols-3 gap-4">
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <h2 className="mb-4 text-sm font-semibold text-[#e2e8f0]">Certificate Authorities</h2>
          <div className="flex flex-col items-center gap-4">
            <DonutChart data={caDonut} centerLabel="1,301" />
            <div className="flex w-full flex-col gap-1.5 text-[11px]">
              {caDonut.map((ca, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: ca.fill }} />
                    <span className="text-[#4b4f58]">{ca.name}</span>
                  </div>
                  <span className="text-[#7c8189]">{ca.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <h2 className="mb-1 text-sm font-semibold text-[#e2e8f0]">Expiring Certificates</h2>
          <p className="mb-4 text-2xl font-semibold text-[#e2e8f0]">499</p>
          <div className="flex flex-col gap-2">
            {expiringRanges.map((range, i) => (
              <div key={i} className="flex items-center justify-between rounded-md px-3 py-2 transition-colors hover:bg-[#1e2127]">
                <span className="text-xs text-[#4b4f58]">{range.range}</span>
                <span className="text-xs text-[#7c8189]">{range.count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <h2 className="mb-4 text-sm font-semibold text-[#e2e8f0]">Signature Algorithm Distribution</h2>
          <div className="flex flex-col items-center gap-4">
            <DonutChart data={sigAlgoDonut} centerLabel="1,301" />
            <div className="flex w-full flex-col gap-1.5 text-[11px]">
              {sigAlgoDonut.map((algo, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: algo.fill }} />
                    <span className="text-[#4b4f58]">{algo.name}</span>
                  </div>
                  <span className="text-[#7c8189]">{algo.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </NexusLayout>
  )
}
