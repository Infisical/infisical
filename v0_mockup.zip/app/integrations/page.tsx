"use client"

import { useState } from "react"
import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import { MoreHorizontal } from "lucide-react"

const subNavItems = [
  "Ticket Systems",
  "Alerting & Notifications",
  "SIEM / SOAR",
  "Cloud Providers",
  "External Scanners",
] as const
type SubNav = (typeof subNavItems)[number]

const ticketIntegrations = [
  { name: "Jira Cloud - INFRA", system: "Jira Cloud", project: "INFRA", trigger: "Critical + High Violations", status: "Active", lastSync: "Feb 24, 2026" },
  { name: "ServiceNow - SEC", system: "ServiceNow", project: "SEC-OPS", trigger: "All Violations", status: "Active", lastSync: "Feb 24, 2026" },
  { name: "Linear - Crypto Team", system: "Linear", project: "CRY", trigger: "New Critical Violations", status: "Paused", lastSync: "Feb 20, 2026" },
]

const alertIntegrations = [
  { name: "Cert Expiry Alert", event: "Certificate Expiry (< 10 days)", channel: "Slack (#security-alerts)", threshold: "< 10 days", status: "Active", lastTriggered: "Feb 23, 2026" },
  { name: "Critical Violation Alert", event: "New Critical Violation", channel: "PagerDuty", threshold: "-", status: "Active", lastTriggered: "Feb 24, 2026" },
  { name: "Risk Score Alert", event: "Risk Score > 5.0", channel: "Email (security@acmecorp.com)", threshold: "> 5.0", status: "Active", lastTriggered: "Never" },
  { name: "Scan Complete", event: "Discovery Scan Completed", channel: "Slack (#infra)", threshold: "-", status: "Active", lastTriggered: "Feb 24, 2026" },
]

const siemConnections = [
  { name: "Splunk Production", platform: "Splunk", exportType: "Real-time Stream", status: "Active", lastExport: "Feb 24, 2026" },
  { name: "Sentinel SOC", platform: "Microsoft Sentinel", exportType: "Batch (Hourly)", status: "Active", lastExport: "Feb 24, 2026" },
]

const cloudProviders = [
  { provider: "AWS", name: "AWS ACM Sync", source: "us-east-1, us-west-2", status: "Synced", lastSynced: "Feb 24, 2026" },
  { provider: "AWS", name: "AWS KMS Sync", source: "us-east-1", status: "Synced", lastSynced: "Feb 24, 2026" },
  { provider: "Azure", name: "Azure Key Vault", source: "prod-keyvault", status: "Synced", lastSynced: "Feb 23, 2026" },
  { provider: "GCP", name: "GCP CAS", source: "project-crypto", status: "Error", lastSynced: "Feb 20, 2026" },
]

const externalScanners = [
  { name: "Qualys TLS Scan", platform: "Qualys", source: "External Perimeter Scan", status: "Active", lastImport: "Feb 22, 2026" },
  { name: "Shodan Monitor", platform: "Shodan", source: "acmecorp.com domains", status: "Active", lastImport: "Feb 24, 2026" },
]

function IntegrationStatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    Active: "#68d391",
    Synced: "#68d391",
    Error: "#fc8181",
    Paused: "#5c6170",
  }
  return (
    <span className="text-[11px]" style={{ color: colors[status] || "#7c8189" }}>
      {status}
    </span>
  )
}

export default function IntegrationsPage() {
  const [activeSubNav, setActiveSubNav] = useState<SubNav>("Ticket Systems")

  return (
    <NexusLayout>
      <PageHeader
        title="Integrations"
        description="Connect Nexus to external tools for ticket management, alerting, and asset discovery."
        docLink="integrations"
      />

      <div className="flex gap-6">
        {/* Left sub-nav */}
        <div className="w-[180px] shrink-0">
          <nav className="flex flex-col gap-0.5">
            {subNavItems.map((item) => (
              <button
                key={item}
                onClick={() => setActiveSubNav(item)}
                className={`border-l-2 px-3 py-2 text-left text-[13px] font-medium transition-colors ${
                  activeSubNav === item
                    ? "border-[#e2e8f0] text-[#e2e8f0]"
                    : "border-transparent text-[#7c8189] hover:text-[#e2e8f0]"
                }`}
              >
                {item}
              </button>
            ))}
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1">
          {activeSubNav === "Ticket Systems" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">Ticket System Integrations</h2>
                  <p className="mt-1 text-xs text-[#7c8189]">Automatically create tickets when violations are detected.</p>
                </div>
                <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                  + Add Integration
                </button>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["NAME", "SYSTEM", "PROJECT/QUEUE", "TRIGGER", "STATUS", "LAST SYNC", ""].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ticketIntegrations.map((item, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{item.name}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.system}</td>
                      <td className="px-4 py-3 font-mono text-xs text-[#7c8189]">{item.project}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.trigger}</td>
                      <td className="px-4 py-3"><IntegrationStatusBadge status={item.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.lastSync}</td>
                      <td className="px-4 py-3">
                        <button className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238]">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeSubNav === "Alerting & Notifications" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">Nexus Alerts</h2>
                  <p className="mt-1 text-xs text-[#7c8189]">Configure alert channels for time-sensitive cryptographic events.</p>
                </div>
                <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                  + Create Alert
                </button>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["NAME", "EVENT TYPE", "CHANNEL", "THRESHOLD", "STATUS", "LAST TRIGGERED", ""].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {alertIntegrations.map((item, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{item.name}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.event}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.channel}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.threshold}</td>
                      <td className="px-4 py-3"><IntegrationStatusBadge status={item.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.lastTriggered}</td>
                      <td className="px-4 py-3">
                        <button className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238]">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeSubNav === "SIEM / SOAR" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">SIEM Connections</h2>
                  <p className="mt-1 text-xs text-[#7c8189]">Export cryptographic risk data to your SIEM/SOAR platforms.</p>
                </div>
                <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                  + Add Connection
                </button>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["NAME", "PLATFORM", "EXPORT TYPE", "STATUS", "LAST EXPORT", ""].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {siemConnections.map((item, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{item.name}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.platform}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.exportType}</td>
                      <td className="px-4 py-3"><IntegrationStatusBadge status={item.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.lastExport}</td>
                      <td className="px-4 py-3">
                        <button className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238]">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeSubNav === "Cloud Providers" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">Cloud Provider Connections</h2>
                  <p className="mt-1 text-xs text-[#7c8189]">Pull certificate and key data from cloud provider services.</p>
                </div>
                <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                  + Add Sync
                </button>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["PROVIDER", "NAME", "SOURCE", "STATUS", "LAST SYNCED", ""].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cloudProviders.map((item, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3">
                        <span className="rounded bg-[#2e3238] px-2 py-0.5 text-[10px] font-medium text-[#7c8189]">{item.provider}</span>
                      </td>
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{item.name}</td>
                      <td className="px-4 py-3 font-mono text-xs text-[#7c8189]">{item.source}</td>
                      <td className="px-4 py-3"><IntegrationStatusBadge status={item.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.lastSynced}</td>
                      <td className="px-4 py-3">
                        <button className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238]">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeSubNav === "External Scanners" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">External Scanner Integrations</h2>
                  <p className="mt-1 text-xs text-[#7c8189]">Import results from third-party security scanning tools.</p>
                </div>
                <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                  + Add Scanner
                </button>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["NAME", "PLATFORM", "SOURCE", "STATUS", "LAST IMPORT", ""].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {externalScanners.map((item, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{item.name}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.platform}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.source}</td>
                      <td className="px-4 py-3"><IntegrationStatusBadge status={item.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{item.lastImport}</td>
                      <td className="px-4 py-3">
                        <button className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238]">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </NexusLayout>
  )
}
