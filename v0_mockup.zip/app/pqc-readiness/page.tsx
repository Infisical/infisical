"use client"

import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  Cell,
  PieChart,
  Pie,
} from "recharts"

const protocolData = [
  { name: "TLSv1.3+1.2", count: 420, color: "#ecc94b" },
  { name: "TLSv1.2", count: 310, color: "#fc8181" },
  { name: "TLSv1.3", count: 180, color: "#68d391" },
  { name: "TLSv1.0", count: 45, color: "#fc8181" },
  { name: "SSL3", count: 12, color: "#fc8181" },
  { name: "Other", count: 54, color: "#5c6170" },
]

const asymmetricKeys = [
  { name: "RSA 2048", count: 263, color: "#fc8181", pqcSafe: false },
  { name: "ECDSA P-256", count: 198, color: "#ecc94b", pqcSafe: false },
  { name: "RSA 4096", count: 145, color: "#ecc94b", pqcSafe: false },
  { name: "ML-KEM-768", count: 98, color: "#68d391", pqcSafe: true },
  { name: "Ed25519", count: 47, color: "#68d391", pqcSafe: false },
  { name: "Other", count: 28, color: "#5c6170", pqcSafe: false },
]

function AsymmetricKeyTick({ x, y, payload }: any) {
  const entry = asymmetricKeys.find((k) => k.name === payload.value)
  return (
    <g transform={`translate(${x},${y})`}>
      <text x={-4} y={0} dy={4} textAnchor="end" fill="#e2e8f0" fontSize={10}>
        {payload.value}
      </text>
      {entry?.pqcSafe && (
        <g transform="translate(-96, -6)">
          <rect width="46" height="14" rx="3" fill="#68d391" fillOpacity={0.15} />
          <text x="23" y="10" textAnchor="middle" fill="#68d391" fontSize={8} fontWeight="600">
            PQC-Safe
          </text>
        </g>
      )}
    </g>
  )
}

const symmetricKeys = [
  { name: "AES-128", count: 340, color: "#ecc94b" },
  { name: "AES-256", count: 285, color: "#68d391" },
  { name: "ChaCha20-256", count: 94, color: "#68d391" },
  { name: "3DES", count: 22, color: "#fc8181" },
  { name: "Other", count: 15, color: "#5c6170" },
]

const libraryDonut = [
  { name: "OpenSSL", value: 420, fill: "#63b3ed" },
  { name: "BouncyCastle", value: 280, fill: "#90cdf4" },
  { name: "JCA", value: 195, fill: "#ecc94b" },
  { name: "Go crypto", value: 140, fill: "#68d391" },
  { name: "Other", value: 86, fill: "#5c6170" },
]

const langDonut = [
  { name: "Java", value: 380, fill: "#fc8181" },
  { name: "Python", value: 290, fill: "#63b3ed" },
  { name: "Go", value: 210, fill: "#68d391" },
  { name: "C/C++", value: 160, fill: "#ecc94b" },
  { name: "C#", value: 55, fill: "#90cdf4" },
  { name: "Dart", value: 26, fill: "#5c6170" },
]

export default function PQCReadinessPage() {
  return (
    <NexusLayout>
      <PageHeader
        title="PQC Readiness"
        description="Assess your organization's readiness for post-quantum cryptographic standards."
        docLink="pqc-readiness"
      />

      {/* Top Strip - Readiness Summary */}
      <div className="mb-6 rounded-lg border border-[#2e3238] bg-[#1a1d21] p-6">
        <div className="flex items-center gap-8">
          {/* Arc Gauge */}
          <div className="flex flex-col items-center">
            <svg width="160" height="95" viewBox="0 0 160 95">
              <path
                d="M 15 85 A 65 65 0 0 1 145 85"
                fill="none"
                stroke="#2e3238"
                strokeWidth="10"
                strokeLinecap="round"
              />
              <path
                d="M 15 85 A 65 65 0 0 1 38 35"
                fill="none"
                stroke="#fc8181"
                strokeWidth="10"
                strokeLinecap="round"
              />
              <text
                x="80"
                y="70"
                textAnchor="middle"
                fill="#e2e8f0"
                fontSize="22"
                fontWeight="600"
              >
                19.05%
              </text>
              <text
                x="80"
                y="88"
                textAnchor="middle"
                fill="#7c8189"
                fontSize="10"
              >
                PQC Readiness
              </text>
            </svg>
            <div className="mt-2 flex gap-4 text-[10px]">
              <div className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-[#fc8181]" />
                <span className="text-[#7c8189]">{"Low (<40%)"}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-[#ecc94b]" />
                <span className="text-[#7c8189]">Moderate (41-80%)</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-[#68d391]" />
                <span className="text-[#7c8189]">{"Good (>80%)"}</span>
              </div>
            </div>
            <span className="mt-2 text-[10px] text-[#fc8181]">Low</span>
          </div>

          {/* Stat Grid */}
          <div className="grid flex-1 grid-cols-4 gap-4">
            <div className="rounded-md border border-[#2e3238] bg-[#111317] p-4 text-center">
              <p className="text-2xl font-semibold text-[#68d391]">235</p>
              <p className="mt-1 text-xs text-[#7c8189]">Safe</p>
            </div>
            <div className="rounded-md border border-[#2e3238] bg-[#111317] p-4 text-center">
              <p className="text-2xl font-semibold text-[#fc8181]">848</p>
              <p className="mt-1 text-xs text-[#7c8189]">Unsafe</p>
            </div>
            <div className="rounded-md border border-[#2e3238] bg-[#111317] p-4 text-center">
              <p className="text-2xl font-semibold text-[#5c6170]">12</p>
              <p className="mt-1 text-xs text-[#7c8189]">Not Evaluated</p>
            </div>
            <div className="group relative rounded-md border border-[#2e3238] bg-[#111317] p-4 text-center">
              <p className="text-2xl font-semibold text-[#5c6170]">138</p>
              <p className="mt-1 text-xs text-[#7c8189]">Not Applicable</p>
              <div className="pointer-events-none absolute -top-12 left-1/2 z-10 hidden w-56 -translate-x-1/2 rounded-md border border-[#3b3f47] bg-[#1a1d21] px-3 py-2 text-[10px] leading-relaxed text-[#7c8189] shadow-lg group-hover:block">
                Assets that do not use cryptography (e.g. static content, non-TLS endpoints).
              </div>
            </div>
          </div>
        </div>
        <p className="mt-4 text-[11px] text-[#7c8189]">
          Based on % of IT assets protected with PQC-safe encryption
        </p>
      </div>

      {/* IT Assets Section */}
      <div className="mb-6 rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-[#e2e8f0]">IT Assets</h2>
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none focus:border-[#90cdf4]">
            <option>All Types</option>
            <option>Application</option>
            <option>Database</option>
            <option>Service</option>
          </select>
        </div>
        <div className="flex items-center gap-8">
          {/* Bubble Visualization */}
          <div className="relative flex h-[140px] w-[280px] items-center justify-center">
            <div className="flex items-end gap-4">
              <div className="flex h-[120px] w-[120px] items-center justify-center rounded-full border border-[#2e3238] bg-[#1a1d21] text-center">
                <div>
                  <p className="text-lg font-semibold text-[#e2e8f0]">1,426</p>
                  <p className="text-[10px] text-[#4b4f58]">Service</p>
                </div>
              </div>
              <div className="flex h-[80px] w-[80px] items-center justify-center rounded-full border border-[#2e3238] bg-[#1a1d21] text-center">
                <div>
                  <p className="text-sm font-semibold text-[#e2e8f0]">364</p>
                  <p className="text-[9px] text-[#4b4f58]">Database</p>
                </div>
              </div>
              <div className="flex h-[70px] w-[70px] items-center justify-center rounded-full border border-[#2e3238] bg-[#1a1d21] text-center">
                <div>
                  <p className="text-sm font-semibold text-[#e2e8f0]">314</p>
                  <p className="text-[9px] text-[#4b4f58]">App</p>
                </div>
              </div>
            </div>
          </div>

          {/* Stat Breakdown */}
          <div className="flex-1">
            <div className="flex flex-col gap-3">
              {[
                { label: "Application", count: 314, color: "#7c8189" },
                { label: "Database", count: 364, color: "#7c8189" },
                { label: "Service", count: 1426, color: "#7c8189" },
              ].map((item, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between border-b border-[#2e3238] pb-3 last:border-0"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-sm"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm text-[#e2e8f0]">{item.label}</span>
                  </div>
                  <span className="text-sm text-[#7c8189]">
                    {item.count.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Protocol Distribution */}
      <div className="mb-6 rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-[#e2e8f0]">
            Protocol Usage Across IT Assets
          </h2>
          <span className="cursor-pointer text-xs text-[#7c8189] hover:text-[#e2e8f0]">
            View all &rarr;
          </span>
        </div>
        <div className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={protocolData} barSize={36}>
              <XAxis
                dataKey="name"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#7c8189", fontSize: 10 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#7c8189", fontSize: 10 }}
                width={40}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1a1d21",
                  border: "1px solid #2e3238",
                  borderRadius: 6,
                  fontSize: 12,
                  color: "#e2e8f0",
                }}
              />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {protocolData.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-3 flex flex-wrap gap-4 text-[10px]">
          <div className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-[#68d391]" />
            <span className="text-[#7c8189]">Safe (TLSv1.3)</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-[#ecc94b]" />
            <span className="text-[#7c8189]">Mixed</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-[#fc8181]" />
            <span className="text-[#7c8189]">Unsafe</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-[#5c6170]" />
            <span className="text-[#7c8189]">Other</span>
          </div>
        </div>
      </div>

      {/* Two-column Key Breakdown */}
      <div className="mb-6 grid grid-cols-2 gap-4">
        {/* Asymmetric Keys */}
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-[#e2e8f0]">
                Asymmetric Keys
              </h2>
              <p className="mt-1 text-2xl font-semibold text-[#e2e8f0]">779</p>
            </div>
            <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none focus:border-[#90cdf4]">
              <option>All Algorithms</option>
              <option>RSA</option>
              <option>ECDSA</option>
              <option>ML-KEM</option>
            </select>
          </div>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={asymmetricKeys}
                layout="vertical"
                barSize={16}
              >
                <XAxis
                  type="number"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#7c8189", fontSize: 10 }}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={150}
                  axisLine={false}
                  tickLine={false}
                  tick={<AsymmetricKeyTick />}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1a1d21",
                    border: "1px solid #2e3238",
                    borderRadius: 6,
                    fontSize: 12,
                    color: "#e2e8f0",
                  }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {asymmetricKeys.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <span className="mt-2 inline-block cursor-pointer text-xs text-[#7c8189] hover:text-[#e2e8f0]">
            View all &rarr;
          </span>
        </div>

        {/* Symmetric Keys */}
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-[#e2e8f0]">
                Symmetric Keys
              </h2>
              <p className="mt-1 text-2xl font-semibold text-[#e2e8f0]">756</p>
            </div>
            <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none focus:border-[#90cdf4]">
              <option>All Algorithms</option>
              <option>AES</option>
              <option>ChaCha20</option>
            </select>
          </div>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={symmetricKeys}
                layout="vertical"
                barSize={16}
              >
                <XAxis
                  type="number"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#7c8189", fontSize: 10 }}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={110}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#e2e8f0", fontSize: 10 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1a1d21",
                    border: "1px solid #2e3238",
                    borderRadius: 6,
                    fontSize: 12,
                    color: "#e2e8f0",
                  }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {symmetricKeys.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <span className="mt-2 inline-block cursor-pointer text-xs text-[#7c8189] hover:text-[#e2e8f0]">
            View all &rarr;
          </span>
        </div>
      </div>

      {/* Cryptographic Library Usage */}
      <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
        <h2 className="mb-4 text-sm font-semibold text-[#e2e8f0]">
          Cryptographic Libraries
        </h2>
        <div className="grid grid-cols-2 gap-6">
          {/* By Library */}
          <div>
            <p className="mb-3 text-xs font-medium text-[#7c8189]">
              Library Distribution
            </p>
            <div className="flex items-center gap-6">
              <div className="relative h-[120px] w-[120px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={libraryDonut}
                      cx="50%"
                      cy="50%"
                      innerRadius={35}
                      outerRadius={55}
                      dataKey="value"
                      strokeWidth={0}
                    >
                      {libraryDonut.map((entry, index) => (
                        <Cell key={index} fill={entry.fill} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <span className="absolute inset-0 flex items-center justify-center text-sm font-semibold text-[#e2e8f0]">
                  1,121
                </span>
              </div>
              <div className="flex flex-col gap-1.5 text-[11px]">
                {libraryDonut.map((lib, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: lib.fill }}
                    />
                    <span className="text-[#7c8189]">
                      {lib.name}: {lib.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* By Language */}
          <div>
            <p className="mb-3 text-xs font-medium text-[#7c8189]">
              Usage by Language
            </p>
            <div className="flex items-center gap-6">
              <div className="relative h-[120px] w-[120px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={langDonut}
                      cx="50%"
                      cy="50%"
                      innerRadius={35}
                      outerRadius={55}
                      dataKey="value"
                      strokeWidth={0}
                    >
                      {langDonut.map((entry, index) => (
                        <Cell key={index} fill={entry.fill} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <span className="absolute inset-0 flex items-center justify-center text-sm font-semibold text-[#e2e8f0]">
                  1,121
                </span>
              </div>
              <div className="flex flex-col gap-1.5 text-[11px]">
                {langDonut.map((lang, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: lang.fill }}
                    />
                    <span className="text-[#7c8189]">
                      {lang.name}: {lang.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </NexusLayout>
  )
}
