"use client"

import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import { Lock, Search, Filter, Columns } from "lucide-react"
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const complianceDonut = [
  { name: "Compliant", value: 2150, fill: "#68d391" },
  { name: "Non-compliant", value: 1515, fill: "#fc8181" },
]

const topViolatedPolicies = [
  { name: "Organization Default PQC Baseline", count: 1245 },
  { name: "Disallow DSA Keys", count: 178 },
  { name: "Certificate Validity Period Check", count: 61 },
  { name: "Small RSA Key Length", count: 59 },
  { name: "TLS 1.2 Cipher Suite Compliance", count: 49 },
]

const policies = [
  { name: "Organization Default PQC Baseline", category: "All", subCategory: "PQC", mode: "Enforcing", type: "User-defined", state: true, compliance: "NIST", controlId: "SC-12 SC-13", violated: "1,245", updated: "Feb 20, 2026" },
  { name: "Minimum AES Key Size 128 bits", category: "Symmetric Keys", subCategory: "Classical", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "-", updated: "Nov 21, 2025" },
  { name: "Weak Post-Quantum Security Posture", category: "Certificates", subCategory: "PQC", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "SC-12 SC-13 RA-5 PM-30", violated: "-", updated: "Nov 21, 2025" },
  { name: "AES Keys < 256 Bits are PQC Unsafe", category: "Symmetric Keys", subCategory: "PQC", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "74", updated: "Nov 21, 2025" },
  { name: "Ensure Keys Based on Quantum-Safe Algorithms", category: "Asymmetric Keys", subCategory: "PQC", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "779", updated: "Nov 21, 2025" },
  { name: "PQC Unsafe Protocols (SSL2-TLSv1.2)", category: "Protocols", subCategory: "PQC", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "840", updated: "Nov 21, 2025" },
  { name: "Disallow DSA Keys", category: "Asymmetric Keys", subCategory: "Classical", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "178", updated: "Nov 21, 2025" },
  { name: "Certificate Validity Period Check", category: "Certificates", subCategory: "Classical", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "SC-12", violated: "61", updated: "Nov 21, 2025" },
  { name: "Small RSA Key Length", category: "Asymmetric Keys", subCategory: "Classical", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "59", updated: "Nov 21, 2025" },
  { name: "TLS 1.2 Cipher Suite Compliance", category: "Protocols", subCategory: "Classical", mode: "Monitoring", type: "System-defined", state: false, compliance: "NIST", controlId: "SC-13", violated: "49", updated: "Nov 21, 2025" },
  { name: "Weak Signature Algorithm", category: "Certificates", subCategory: "Classical", mode: "Monitoring", type: "System-defined", state: true, compliance: "NIST", controlId: "-", violated: "6", updated: "Nov 21, 2025" },
]

export default function PoliciesPage() {
  return (
    <NexusLayout>
      <PageHeader
        title="Policies & Compliance"
        description="Apply NIST policies and organizational mandates to evaluate risk, classify vulnerabilities, and ensure standards compliance."
        docLink="policies"
      />

      {/* Top Summary Row */}
      <div className="mb-6 grid grid-cols-3 gap-4">
        {/* Card 1 - Compliance Status */}
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wider text-[#7c8189]">
              Compliance Status
            </p>
            <select className="rounded border border-[#2e3238] bg-[#111317] px-2 py-1 text-[10px] text-[#7c8189] outline-none">
              <option>All</option>
              <option>Certificates</option>
              <option>Keys</option>
              <option>Protocols</option>
            </select>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative h-[90px] w-[90px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={complianceDonut}
                    cx="50%"
                    cy="50%"
                    innerRadius={28}
                    outerRadius={42}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {complianceDonut.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-[#e2e8f0]">
                3,665
              </span>
            </div>
            <div className="flex flex-col gap-1.5 text-[11px]">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#68d391]" />
                <span className="text-[#7c8189]">Compliant: 2,150</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#fc8181]" />
                <span className="text-[#7c8189]">Non-compliant: 1,515</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 2 - Violations Distribution */}
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <p className="mb-1 text-xs font-medium uppercase tracking-wider text-[#7c8189]">
            Total Violations Distribution
          </p>
          <p className="mb-4 text-2xl font-semibold text-[#e2e8f0]">1,700</p>
          {/* Stacked bar */}
          <div className="mb-3 flex h-4 w-full overflow-hidden rounded-full">
            <div className="bg-[#fc8181]" style={{ width: `${(1371 / 1700) * 100}%` }} />
            <div className="bg-[#ecc94b]" style={{ width: `${(213 / 1700) * 100}%` }} />
            <div className="bg-[#63b3ed]" style={{ width: `${(116 / 1700) * 100}%` }} />
          </div>
          <div className="flex gap-4 text-[10px]">
            <div className="flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-[#fc8181]" />
              <span className="text-[#7c8189]">Certificates: 1,371</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-[#ecc94b]" />
              <span className="text-[#7c8189]">Keys: 213</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-[#63b3ed]" />
              <span className="text-[#7c8189]">Protocols: 116</span>
            </div>
          </div>
        </div>

        {/* Card 3 - Top Violated Policies */}
        <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
          <p className="mb-3 text-xs font-medium uppercase tracking-wider text-[#7c8189]">
            Top Violated Policies
          </p>
          <div className="flex flex-col">
            {topViolatedPolicies.map((p, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 text-xs">
                <span className="truncate text-[#e2e8f0]">{p.name}</span>
                <span className="ml-2 shrink-0 text-[#7c8189]">
                  {p.count.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Policies Table */}
      <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
              <option>Category</option>
              <option>Symmetric Keys</option>
              <option>Asymmetric Keys</option>
              <option>Certificates</option>
              <option>Protocols</option>
            </select>
            <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
              <option>Sub-Category</option>
              <option>PQC</option>
              <option>Classical</option>
            </select>
            <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
              <option>Policy State</option>
              <option>Activated</option>
              <option>Deactivated</option>
            </select>
            <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
              <option>Compliance</option>
              <option>NIST</option>
              <option>PCI DSS</option>
            </select>
            <div className="flex items-center rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5">
              <Search className="mr-2 h-3.5 w-3.5 text-[#5c6170]" />
              <input
                type="text"
                placeholder="Search policies..."
                className="w-40 bg-transparent text-xs text-[#e2e8f0] placeholder-[#5c6170] outline-none"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 rounded-md border border-[#2e3238] px-3 py-1.5 text-xs text-[#7c8189] hover:bg-[#1a1d21]">
              <Columns className="h-3.5 w-3.5" />
            </button>
            <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
              + Create Policy
            </button>
          </div>
        </div>

        <table className="w-full">
          <thead>
            <tr className="border-b border-[#2e3238] bg-[#111317]">
              <th className="w-8 px-4 py-3">
                <input type="checkbox" className="rounded border-[#2e3238]" />
              </th>
              {["POLICY NAME", "CATEGORY", "SUB-CATEGORY", "MODE", "TYPE", "STATE", "COMPLIANCE", "CONTROL ID", "VIOLATED ASSETS", "LAST UPDATED"].map((h) => (
                <th key={h} className="px-3 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {policies.map((policy, i) => (
              <tr key={i} className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                <td className="px-4 py-3">
                  <input type="checkbox" className="rounded border-[#2e3238]" />
                </td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-1.5">
                    <Lock className="h-3 w-3 text-[#5c6170]" />
                    <span className="text-xs text-[#e2e8f0]">{policy.name}</span>
                  </div>
                </td>
                <td className="px-3 py-3 text-xs text-[#7c8189]">{policy.category}</td>
                <td className="px-3 py-3 text-xs text-[#4b4f58]">{policy.subCategory}</td>
                <td className="px-3 py-3 text-xs text-[#7c8189]">{policy.mode}</td>
                <td className="px-3 py-3 text-xs text-[#7c8189]">{policy.type}</td>
                <td className="px-3 py-3">
                  <span className={`text-[11px] ${policy.state ? "text-[#68d391]" : "text-[#4b4f58]"}`}>
                    {policy.state ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <span className="rounded bg-[#2e3238] px-1.5 py-0.5 text-[10px] text-[#7c8189]">
                    {policy.compliance}
                  </span>
                </td>
                <td className="px-3 py-3">
                  {policy.controlId !== "-" ? (
                    <div className="flex flex-wrap gap-1">
                      {policy.controlId.split(" ").map((id) => (
                        <span key={id} className="rounded bg-[#2e3238] px-1.5 py-0.5 text-[10px] text-[#7c8189]">
                          {id}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs text-[#5c6170]">-</span>
                  )}
                </td>
                <td className="px-3 py-3">
                  {policy.violated !== "-" ? (
                    <span className="text-xs text-[#7c8189]">
                      {policy.violated}
                    </span>
                  ) : (
                    <span className="text-xs text-[#5c6170]">-</span>
                  )}
                </td>
                <td className="px-3 py-3 text-xs text-[#7c8189]">{policy.updated}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </NexusLayout>
  )
}
