"use client"

import { useState } from "react"
import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import { Search, Download, X, MoreHorizontal } from "lucide-react"

const violations = [
  { severity: "Critical", policy: "Non Quantum-Safe Algorithm", category: "PQC", asset: "key-a1b2c3 (RSA-2048)", assetType: "Asymmetric Key", itAsset: "Secrets-Prod", detected: "Feb 24, 2026", status: "Open", assignedTo: "ashwin@infisical.com" },
  { severity: "Critical", policy: "PQC Unsafe Protocols (SSL2-TLSv1.2)", category: "PQC", asset: "192.168.1.50:443 (TLS 1.0)", assetType: "Protocol", itAsset: "Legacy App", detected: "Feb 24, 2026", status: "Open", assignedTo: "daniel@infisical.com" },
  { severity: "Critical", policy: "Expired Certificate", category: "Classical", asset: "api.acmecorp.com (RSA-2048)", assetType: "Certificate", itAsset: "API Gateway", detected: "Feb 23, 2026", status: "In Progress", assignedTo: "arsh@infisical.com" },
  { severity: "High", policy: "Ensure Keys Based on Quantum-Safe Algorithms", category: "PQC", asset: "key-j1k2l3 (ECDSA-256)", assetType: "Asymmetric Key", itAsset: "KMS_TEST", detected: "Feb 23, 2026", status: "Open", assignedTo: "ashwin@infisical.com" },
  { severity: "High", policy: "Small RSA Key Length", category: "Classical", asset: "db.internal.corp (RSA-2048)", assetType: "Certificate", itAsset: "Database Cluster", detected: "Feb 22, 2026", status: "Accepted Risk", assignedTo: "carlos@infisical.com" },
  { severity: "High", policy: "Disallow DSA Keys", category: "Classical", asset: "key-x9y8z7 (DSA-1024)", assetType: "Asymmetric Key", itAsset: "Secrets-Staging", detected: "Feb 22, 2026", status: "Open", assignedTo: "" },
  { severity: "Medium", policy: "Certificate Validity Period Check", category: "Classical", asset: "cdn.acmecorp.com (ECDSA-384)", assetType: "Certificate", itAsset: "CDN Edge", detected: "Feb 21, 2026", status: "Resolved", assignedTo: "daniel@infisical.com" },
  { severity: "Medium", policy: "AES Keys < 256 Bits are PQC Unsafe", category: "PQC", asset: "key-m4n5o6 (AES-128)", assetType: "Symmetric Key", itAsset: "Secrets-Prod", detected: "Feb 21, 2026", status: "Open", assignedTo: "" },
  { severity: "Medium", policy: "Weak Signature Algorithm", category: "Classical", asset: "vault.acmecorp.com (SHA-1)", assetType: "Certificate", itAsset: "Vault Server", detected: "Feb 20, 2026", status: "Open", assignedTo: "arsh@infisical.com" },
  { severity: "High", policy: "TLS 1.2 Cipher Suite Compliance", category: "Classical", asset: "10.0.5.33:443 (RC4-SHA)", assetType: "Protocol", itAsset: "Staging Server", detected: "Feb 20, 2026", status: "Open", assignedTo: "" },
]

function SeverityDot({ severity }: { severity: string }) {
  const colors: Record<string, string> = {
    Critical: "#fc8181",
    High: "#ecc94b",
    Medium: "#ecc94b",
    Low: "#5c6170",
  }
  return (
    <div className="flex items-center gap-1.5">
      <span
        className="h-2 w-2 rounded-full"
        style={{ backgroundColor: colors[severity] }}
      />
      <span className="text-xs" style={{ color: colors[severity] }}>
        {severity}
      </span>
    </div>
  )
}

function ViolationStatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    Open: "#fc8181",
    "In Progress": "#ecc94b",
    "Accepted Risk": "#7c8189",
    Resolved: "#68d391",
  }
  return (
    <span className="text-[11px]" style={{ color: colors[status] }}>
      {status}
    </span>
  )
}

function ViolationDrawer({ violation, onClose }: { violation: typeof violations[0]; onClose: () => void }) {
  return (
    <div className="fixed inset-y-0 right-0 z-50 flex w-[420px] flex-col border-l border-[#2e3238] bg-[#1a1d21] shadow-2xl">
      <div className="flex items-center justify-between border-b border-[#2e3238] px-5 py-4">
        <div className="flex items-center gap-2">
          <SeverityDot severity={violation.severity} />
          <h3 className="text-sm font-semibold text-[#e2e8f0]">{violation.policy}</h3>
        </div>
        <button onClick={onClose} className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238] hover:text-[#e2e8f0]">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-5">
        <div className="mb-5">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Asset Detail</h4>
          <div className="flex flex-col gap-2 text-xs">
            {[
              ["Asset", violation.asset],
              ["Type", violation.assetType],
              ["IT Asset", violation.itAsset],
              ["Detected", violation.detected],
              ["Status", violation.status],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between">
                <span className="text-[#4b4f58]">{label}</span>
                <span className="text-[#e2e8f0]">{value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-5 border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Policy Description</h4>
          <p className="text-xs leading-relaxed text-[#7c8189]">
            This policy detects cryptographic assets that do not meet post-quantum security requirements. Assets using classical algorithms like RSA, DSA, or ECDSA are flagged as quantum-unsafe since they can be broken by sufficiently powerful quantum computers.
          </p>
        </div>

        <div className="mb-5 border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Remediation Recommendation</h4>
          <div className="rounded-md border border-[#2e3238] bg-[#111317] p-3">
            <p className="text-xs leading-relaxed text-[#e2e8f0]">
              This RSA-2048 key is not quantum-safe. Rotate using ML-KEM-768 (CRYSTALS-Kyber) which is NIST-standardized. Estimated effort: Medium.
            </p>
          </div>
        </div>

        <div className="mb-5 border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Source</h4>
          <span className="text-xs text-[#7c8189]">{violation.itAsset} (Infisical Project)</span>
        </div>

        <div className="border-t border-[#2e3238] pt-4">
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#7c8189]">Linked Tickets</h4>
          <div className="flex items-center gap-2 text-xs">
            <span className="rounded bg-[#2e3238] px-2 py-0.5 font-mono text-[#7c8189]">INFRA-2847</span>
            <span className="text-[11px] text-[#ecc94b]">In Progress</span>
          </div>
        </div>
      </div>

      <div className="flex gap-2 border-t border-[#2e3238] px-5 py-3">
        <button className="flex-1 rounded-md border border-[#3b3f47] bg-transparent px-3 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
          Create Ticket
        </button>
        <button className="rounded-md border border-[#2e3238] px-3 py-2 text-xs text-[#7c8189] hover:bg-[#2e3238] hover:text-[#e2e8f0]">
          Accept Risk
        </button>
        <button className="rounded-md border border-[#2e3238] px-3 py-2 text-xs text-[#7c8189] hover:bg-[#2e3238] hover:text-[#e2e8f0]">
          Resolve
        </button>
      </div>
    </div>
  )
}

export default function ViolationsPage() {
  const [selectedViolation, setSelectedViolation] = useState<typeof violations[0] | null>(null)

  return (
    <NexusLayout>
      <PageHeader
        title="Violations"
        description="Review, triage, and remediate active cryptographic policy violations across your organization."
        docLink="violations"
      />

      {/* Top summary bar - uniform cards, color only on the number */}
      <div className="mb-6 flex items-center gap-4">
        {[
          { label: "Total Active", value: "1,700", color: "#e2e8f0" },
          { label: "Critical", value: "405", color: "#fc8181" },
          { label: "High", value: "264", color: "#ecc94b" },
          { label: "Medium", value: "22", color: "#ecc94b" },
          { label: "Low", value: "0", color: "#5c6170" },
        ].map((card) => (
          <div key={card.label} className="rounded-lg border border-[#2e3238] bg-[#1a1d21] px-5 py-3">
            <p className="text-[10px] uppercase tracking-wider text-[#4b4f58]">{card.label}</p>
            <p className="text-xl font-semibold" style={{ color: card.color }}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Filter bar */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
            <option>All Policies</option>
          </select>
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
            <option>Category</option>
            <option>PQC</option>
            <option>Classical</option>
          </select>
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
            <option>Asset Type</option>
          </select>
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
            <option>Severity</option>
          </select>
          <select className="rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5 text-xs text-[#7c8189] outline-none">
            <option>Status</option>
          </select>
          <div className="flex items-center rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5">
            <Search className="mr-2 h-3.5 w-3.5 text-[#4b4f58]" />
            <input
              type="text"
              placeholder="Search by asset, policy, or host..."
              className="w-48 bg-transparent text-xs text-[#e2e8f0] placeholder-[#4b4f58] outline-none"
            />
          </div>
        </div>
        <button className="flex items-center gap-1.5 rounded-md border border-[#2e3238] px-3 py-1.5 text-xs text-[#7c8189] hover:bg-[#1a1d21]">
          <Download className="h-3.5 w-3.5" />
          Export CSV
        </button>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21]">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#2e3238]">
              {["SEVERITY", "POLICY NAME", "CATEGORY", "ASSET", "ASSET TYPE", "LINKED IT ASSET", "ASSIGNED TO", "DETECTED", "STATUS", ""].map((h) => (
                <th key={h} className="px-3 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#4b4f58]">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {violations.map((v, i) => (
              <tr
                key={i}
                className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1e2127]"
                onClick={() => setSelectedViolation(v)}
              >
                <td className="px-3 py-3"><SeverityDot severity={v.severity} /></td>
                <td className="px-3 py-3 text-xs text-[#e2e8f0]">{v.policy}</td>
                <td className="px-3 py-3 text-xs text-[#4b4f58]">{v.category}</td>
                <td className="px-3 py-3 font-mono text-xs text-[#7c8189]">{v.asset}</td>
                <td className="px-3 py-3 text-xs text-[#4b4f58]">{v.assetType}</td>
                <td className="px-3 py-3 text-xs text-[#7c8189]">{v.itAsset}</td>
                <td className="px-3 py-3 text-xs text-[#7c8189]">
                  {v.assignedTo ? (
                    <span>{v.assignedTo.split("@")[0]}</span>
                  ) : (
                    <span className="text-[#4b4f58]">Unassigned</span>
                  )}
                </td>
                <td className="px-3 py-3 text-xs text-[#4b4f58]">{v.detected}</td>
                <td className="px-3 py-3"><ViolationStatusBadge status={v.status} /></td>
                <td className="px-3 py-3">
                  <button
                    className="rounded p-1 text-[#4b4f58] hover:bg-[#2e3238] hover:text-[#7c8189]"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <MoreHorizontal className="h-3.5 w-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedViolation && (
        <ViolationDrawer
          violation={selectedViolation}
          onClose={() => setSelectedViolation(null)}
        />
      )}
    </NexusLayout>
  )
}
