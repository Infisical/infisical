"use client"

import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  BarChart,
  Bar,
  Tooltip,
  Cell,
  PieChart,
  Pie,
} from "recharts"

const riskTrendData = [
  { date: "Nov 17", score: 6.5 },
  { date: "Nov 18", score: 4.2 },
  { date: "Nov 19", score: 2.8 },
  { date: "Nov 20", score: 1.1 },
  { date: "Nov 21", score: 0.15 },
]

const sparklineData = [
  { v: 5.2 }, { v: 4.8 }, { v: 3.9 }, { v: 2.1 }, { v: 1.2 }, { v: 0.5 }, { v: 0.15 },
]

const scannedDonutData = [
  { name: "Compliant", value: 2150, fill: "#68d391" },
  { name: "Non-compliant", value: 1515, fill: "#fc8181" },
]

const classicalViolations = [
  { name: "Expired Certificate", count: 359, color: "#fc8181" },
  { name: "Certificate Validity Period Check", count: 61, color: "#ecc94b" },
  { name: "Small RSA Key Length", count: 59, color: "#ecc94b" },
  { name: "TLS 1.2 Cipher Suite", count: 49, color: "#ecc94b" },
]

const topPolicies = [
  { name: "Non Quantum-Safe Algorithm", count: 1066 },
  { name: "PQC Unsafe Protocols (SSL2, SSL3, TLSv1.0-1.2)", count: 840 },
  { name: "Ensure Keys Based on Quantum-Safe Algorithms", count: 779 },
  { name: "Non-PQC Asymmetric Algorithms in Use", count: 474 },
  { name: "AES Keys Less Than 256 Bits", count: 74 },
]

const InfisicalTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-md border border-[#3b3f47] bg-[#1a1d21] px-3 py-2 text-xs shadow-md">
      <p className="text-[#7c8189]">{label}</p>
      <p className="font-medium text-[#e2e8f0]">{payload[0].value}</p>
    </div>
  )
}

export default function OverviewPage() {
  return (
    <NexusLayout>
      <PageHeader
        title="Nexus Overview"
        description="Monitor your organization's post-quantum cryptographic security posture."
      />

      {/* KPI Cards */}
      <div className="mb-6 grid grid-cols-4 gap-4">
        {/* Enterprise Risk Score */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">
            Enterprise Risk Score
          </p>
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-semibold text-[#e2e8f0]">0.15</span>
            <span className="text-lg text-[#4b4f58]">/10</span>
          </div>
          <p className="mt-1 text-[11px] text-[#4b4f58]">Based on avg. CVSS score across all IT assets</p>
          <p className="mt-2 text-[10px] text-[#68d391]">Low</p>
          <div className="mt-2 h-10">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sparklineData}>
                <Line type="monotone" dataKey="v" stroke="#68d391" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* PQC Readiness */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">
            PQC Readiness
          </p>
          <span className="text-3xl font-semibold text-[#e2e8f0]">11.17%</span>
          <div className="mt-3 flex justify-center">
            <svg width="100" height="60" viewBox="0 0 100 60">
              <path d="M 10 55 A 40 40 0 0 1 90 55" fill="none" stroke="#2e3238" strokeWidth="6" strokeLinecap="round" />
              <path d="M 10 55 A 40 40 0 0 1 19 30" fill="none" stroke="#fc8181" strokeWidth="6" strokeLinecap="round" />
            </svg>
          </div>
          <p className="mt-2 text-center text-[10px] text-[#fc8181]">Low</p>
        </div>

        {/* Total Violations */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">
            Total Violations
          </p>
          <span className="text-3xl font-semibold text-[#e2e8f0]">1,700</span>
          <div className="mt-4 flex flex-col gap-2">
            {[
              { label: "Certificates", value: "1,371", dot: "#fc8181" },
              { label: "Keys", value: "213", dot: "#ecc94b" },
              { label: "Protocols", value: "116", dot: "#63b3ed" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: item.dot }} />
                  <span className="text-[#7c8189]">{item.label}</span>
                </div>
                <span className="text-[#a1a5ab]">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Scanned Objects */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">
            Scanned Objects
          </p>
          <span className="text-3xl font-semibold text-[#e2e8f0]">3,665</span>
          <div className="mt-3 flex items-center justify-center">
            <div className="relative h-[80px] w-[80px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={scannedDonutData} cx="50%" cy="50%" innerRadius={28} outerRadius={38} dataKey="value" startAngle={90} endAngle={-270} strokeWidth={0}>
                    {scannedDonutData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="mt-2 flex justify-center gap-4 text-[10px]">
            <div className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-[#68d391]" />
              <span className="text-[#7c8189]">2,150</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-[#fc8181]" />
              <span className="text-[#7c8189]">1,515</span>
            </div>
          </div>
        </div>
      </div>

      {/* Row 2 */}
      <div className="mb-6 grid grid-cols-[1fr_0.85fr_0.65fr] gap-4">
        {/* Top Violated PQC Policies */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-medium text-[#e2e8f0]">Top Violated PQC Policies</h2>
            <span className="cursor-pointer text-xs text-[#7c8189] hover:text-[#a1a5ab]">View all</span>
          </div>
          <div className="flex flex-col">
            {topPolicies.map((policy, i) => (
              <div key={i} className="flex items-center justify-between border-b border-[#2e3238] py-3 last:border-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#4b4f58]">{i + 1}.</span>
                  <span className="text-[13px] text-[#a1a5ab]">{policy.name}</span>
                </div>
                <span className="text-sm text-[#7c8189]">{policy.count.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Noncompliance Overview */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <h2 className="mb-4 text-sm font-medium text-[#e2e8f0]">Violations by Category</h2>
          <div className="mb-5 grid grid-cols-3 gap-4">
            {[
              { label: "Certificates", total: "1,371", classical: "485", pqc: "886" },
              { label: "Keys", total: "213", classical: "59", pqc: "154" },
              { label: "Protocols", total: "116", classical: "49", pqc: "67" },
            ].map((col) => (
              <div key={col.label}>
                <p className="mb-2 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">{col.label}</p>
                <p className="text-lg font-semibold text-[#e2e8f0]">{col.total}</p>
                <div className="mt-2 flex flex-col gap-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#4b4f58]">Classical:</span>
                    <span className="text-[#7c8189]">{col.classical}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#4b4f58]">PQC:</span>
                    <span className="text-[#7c8189]">{col.pqc}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-md border border-[#2e3238] bg-[#111317] p-4">
            <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">Ticket Status Overview</p>
            <div className="flex items-center gap-4">
              <div className="relative h-[60px] w-[60px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Open", value: 2, fill: "#fc8181" },
                        { name: "In Progress", value: 1, fill: "#ecc94b" },
                        { name: "Closed", value: 1, fill: "#68d391" },
                      ]}
                      cx="50%" cy="50%" innerRadius={18} outerRadius={28} dataKey="value" strokeWidth={0}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-[#e2e8f0]">4</span>
              </div>
              <div className="flex flex-col gap-1 text-[11px]">
                <span className="text-[#7c8189]">Open: <span className="text-[#a1a5ab]">2</span></span>
                <span className="text-[#7c8189]">In Progress: <span className="text-[#a1a5ab]">1</span></span>
                <span className="text-[#7c8189]">Closed: <span className="text-[#a1a5ab]">1</span></span>
              </div>
            </div>
          </div>
        </div>

        {/* Risk Trend + Quick Actions */}
        <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
          <h2 className="mb-4 text-sm font-medium text-[#e2e8f0]">Risk Score (Last 7 Days)</h2>
          <div className="h-[130px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={riskTrendData}>
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#4b4f58", fontSize: 10 }} />
                <YAxis domain={[0, 10]} axisLine={false} tickLine={false} tick={{ fill: "#4b4f58", fontSize: 10 }} width={20} />
                <Tooltip content={<InfisicalTooltip />} />
                <Line type="monotone" dataKey="score" stroke="#68d391" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-5 border-t border-[#2e3238] pt-4">
            <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-[#7c8189]">Quick Actions</p>
            <div className="flex flex-col gap-2">
              <button className="w-full rounded-md border border-[#2e3238] bg-transparent px-4 py-2 text-xs text-[#a1a5ab] transition-colors hover:bg-[#2e3238] hover:text-[#e2e8f0]">
                + Create Policy
              </button>
              <button className="w-full rounded-md border border-[#2e3238] bg-transparent px-4 py-2 text-xs text-[#a1a5ab] transition-colors hover:bg-[#2e3238] hover:text-[#e2e8f0]">
                Run Discovery Scan
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3 - Classical Violations */}
      <div className="rounded-md border border-[#2e3238] bg-[#1a1d21] p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-medium text-[#e2e8f0]">Top Classical Policy Violations</h2>
          <select className="rounded-md border border-[#3b3f47] bg-[#111317] px-3 py-1.5 text-xs text-[#a1a5ab] outline-none">
            <option>All</option>
            <option>Certificates</option>
            <option>Keys</option>
            <option>Protocols</option>
          </select>
        </div>
        <div className="h-[180px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={classicalViolations} layout="vertical" barSize={18}>
              <XAxis type="number" axisLine={false} tickLine={false} tick={{ fill: "#4b4f58", fontSize: 10 }} />
              <YAxis type="category" dataKey="name" width={220} axisLine={false} tickLine={false} tick={{ fill: "#a1a5ab", fontSize: 11 }} />
              <Tooltip content={<InfisicalTooltip />} />
              <Bar dataKey="count" radius={[0, 3, 3, 0]}>
                {classicalViolations.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </NexusLayout>
  )
}
