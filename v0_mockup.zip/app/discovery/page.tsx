"use client"

import { useState } from "react"
import { NexusLayout } from "@/components/nexus/nexus-layout"
import { PageHeader } from "@/components/nexus/page-header"
import {
  Search,
  MoreHorizontal,
  ExternalLink,
  Download,
} from "lucide-react"

const subNavItems = ["Jobs", "Installations", "Scan History"] as const
type SubNav = (typeof subNavItems)[number]

const discoveryJobs = [
  { name: "prod-network-scan", type: "Network Scan", target: "172.16.0.0/24", ports: "443, 8443", status: "Completed", lastScan: "Feb 24, 2026", assets: 1247 },
  { name: "k8s-cluster-prod", type: "Kubernetes Scan", target: "prod-cluster", ports: "-", status: "Completed", lastScan: "Feb 23, 2026", assets: 384 },
  { name: "infisical-pki", type: "Infisical PKI", target: "PKI Demo, Marsh McLennan", ports: "-", status: "Synced", lastScan: "Live", assets: 1301 },
  { name: "infisical-kms", type: "Infisical KMS", target: "KMS_TEST", ports: "-", status: "Synced", lastScan: "Live", assets: 779 },
  { name: "ct-log-monitor", type: "CT Log Monitoring", target: "All CAs", ports: "-", status: "Running", lastScan: "In Progress (First Run)", assets: 0 },
]

const installations = [
  { name: "agent-prod-01", host: "prod-worker-1.acmecorp.com", version: "1.2.0", heartbeat: "2 min ago", status: "Online" },
  { name: "agent-staging-01", host: "staging-app.acmecorp.com", version: "1.1.8", heartbeat: "5 min ago", status: "Online" },
  { name: "agent-dev-01", host: "dev-server.acmecorp.com", version: "1.0.5", heartbeat: "3 days ago", status: "Offline" },
]

const scanHistory = [
  { scanId: "scan-9281", job: "prod-network-scan", type: "Network", started: "Feb 24, 2026 11:00 PM", completed: "Feb 24, 2026 11:04 PM", duration: "4m 32s", assets: 1247, status: "Completed" },
  { scanId: "scan-9280", job: "k8s-cluster-prod", type: "Kubernetes", started: "Feb 23, 2026 03:00 AM", completed: "Feb 23, 2026 03:02 AM", duration: "2m 15s", assets: 384, status: "Completed" },
  { scanId: "scan-9279", job: "prod-network-scan", type: "Network", started: "Feb 17, 2026 11:00 PM", completed: "Feb 17, 2026 11:05 PM", duration: "5m 01s", assets: 1198, status: "Completed" },
  { scanId: "scan-9278", job: "prod-network-scan", type: "Network", started: "Feb 10, 2026 11:00 PM", completed: "-", duration: "-", assets: 0, status: "Failed" },
]

function JobStatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    Completed: "#68d391",
    Synced: "#68d391",
    Running: "#7c8189",
    Failed: "#fc8181",
  }
  return (
    <span className="text-[11px]" style={{ color: colors[status] || "#7c8189" }}>
      {status}
    </span>
  )
}

export default function DiscoveryPage() {
  const [activeSubNav, setActiveSubNav] = useState<SubNav>("Jobs")

  return (
    <NexusLayout>
      <PageHeader
        title="Discovery"
        description="Configure scan profiles to discover cryptographic keys, certificates, and protocols across your hybrid environment."
        docLink="discovery"
      />

      <div className="flex gap-6">
        {/* Left sub-nav */}
        <div className="w-[160px] shrink-0">
          <nav className="flex flex-col gap-0.5">
            {subNavItems.map((item) => (
              <button
                key={item}
                onClick={() => setActiveSubNav(item)}
                className={`border-l-2 px-3 py-2 text-left text-[13px] font-medium transition-colors ${
                  activeSubNav === item
                    ? "border-[#e2e8f0] text-[#e2e8f0]"
                    : "border-transparent text-[#7c8189] hover:text-[#e2e8f0]"
                }`}
              >
                {item}
              </button>
            ))}
          </nav>
        </div>

        {/* Main content area */}
        <div className="flex-1">
          {activeSubNav === "Jobs" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-1 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">
                    Discovery Jobs
                  </h2>
                  <div className="mt-1 flex items-center gap-2">
                    <p className="text-xs text-[#7c8189]">
                      Configure and manage scans to discover certificates across your infrastructure.
                    </p>
                    <a href="#" className="inline-flex items-center gap-1 text-[11px] text-[#63b3ed] hover:underline">
                      Documentation <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
                <button className="rounded-md border border-[#3b3f47] bg-transparent px-4 py-2 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                  + Add Job
                </button>
              </div>

              {/* Search */}
              <div className="my-4 flex items-center rounded-md border border-[#2e3238] bg-[#111317] px-3 py-1.5">
                <Search className="mr-2 h-3.5 w-3.5 text-[#5c6170]" />
                <input
                  type="text"
                  placeholder="Search by name, domain, or IP..."
                  className="w-full bg-transparent text-xs text-[#e2e8f0] placeholder-[#5c6170] outline-none"
                />
              </div>

              {/* Table */}
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["NAME", "SCAN TYPE", "TARGET", "PORTS", "STATUS", "LAST SCAN", "ASSETS FOUND", ""].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {discoveryJobs.map((job, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{job.name}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{job.type}</td>
                      <td className="px-4 py-3 font-mono text-xs text-[#7c8189]">{job.target}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{job.ports}</td>
                      <td className="px-4 py-3"><JobStatusBadge status={job.status} /></td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{job.lastScan}</td>
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{job.assets > 0 ? job.assets.toLocaleString() : "-"}</td>
                      <td className="px-4 py-3">
                        <button className="rounded p-1 text-[#7c8189] hover:bg-[#2e3238] hover:text-[#e2e8f0]">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeSubNav === "Installations" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-[#e2e8f0]">Agent Installations</h2>
                  <p className="mt-1 text-xs text-[#7c8189]">Deploy the Nexus agent to local environments for filesystem scanning.</p>
                </div>
              </div>

              {/* Download links */}
              <div className="mb-5 grid grid-cols-3 gap-3">
                {["Linux (amd64)", "macOS (arm64)", "Windows (x64)"].map((os) => (
                  <button key={os} className="flex items-center gap-2 rounded-md border border-[#2e3238] bg-[#111317] px-4 py-3 text-xs text-[#e2e8f0] transition-colors hover:bg-[#1a1d21]">
                    <Download className="h-4 w-4 text-[#7c8189]" />
                    {os}
                  </button>
                ))}
              </div>

              {/* Token generation */}
              <div className="mb-5 rounded-md border border-[#2e3238] bg-[#111317] p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-[#e2e8f0]">Agent Authentication Token</p>
                    <p className="mt-1 text-[11px] text-[#7c8189]">Generate a token for your agent to authenticate with Nexus.</p>
                  </div>
                  <button className="rounded-md border border-[#3b3f47] bg-transparent px-3 py-1.5 text-xs font-medium text-[#e2e8f0] hover:bg-[#2e3238]">
                    Generate Token
                  </button>
                </div>
              </div>

              {/* Agent status table */}
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["AGENT NAME", "HOST", "VERSION", "LAST HEARTBEAT", "STATUS"].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {installations.map((agent, i) => (
                    <tr key={i} className="border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{agent.name}</td>
                      <td className="px-4 py-3 font-mono text-xs text-[#7c8189]">{agent.host}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{agent.version}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{agent.heartbeat}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[11px] ${agent.status === "Online" ? "text-[#68d391]" : "text-[#4b4f58]"}`}>{agent.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeSubNav === "Scan History" && (
            <div className="rounded-lg border border-[#2e3238] bg-[#1a1d21] p-5">
              <h2 className="mb-4 text-sm font-semibold text-[#e2e8f0]">Scan History</h2>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2e3238]">
                    {["SCAN ID", "JOB NAME", "TYPE", "STARTED", "COMPLETED", "DURATION", "ASSETS FOUND", "STATUS"].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-[11px] font-medium uppercase tracking-[0.05em] text-[#7c8189]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {scanHistory.map((scan, i) => (
                    <tr key={i} className="cursor-pointer border-b border-[#2e3238] transition-colors hover:bg-[#1a1d21]">
                      <td className="px-4 py-3 font-mono text-xs text-[#e2e8f0]">{scan.scanId}</td>
                      <td className="px-4 py-3 text-xs text-[#e2e8f0]">{scan.job}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{scan.type}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{scan.started}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{scan.completed}</td>
                      <td className="px-4 py-3 text-xs text-[#7c8189]">{scan.duration}</td>
                      <td className="px-4 py-3 text-xs font-medium text-[#e2e8f0]">{scan.assets > 0 ? scan.assets.toLocaleString() : "-"}</td>
                      <td className="px-4 py-3"><JobStatusBadge status={scan.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </NexusLayout>
  )
}
