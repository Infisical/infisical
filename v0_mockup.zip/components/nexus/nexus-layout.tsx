"use client"

import { TopNav } from "./top-nav"
import { HorizontalNav } from "./sidebar-nav"

export function NexusLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-[#0d0f11]">
      <TopNav />
      <HorizontalNav />
      <main className="mx-auto w-full max-w-[1400px] flex-1 px-8 py-8">
        {children}
      </main>
    </div>
  )
}
