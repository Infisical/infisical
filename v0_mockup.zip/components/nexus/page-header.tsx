import { ExternalLink } from "lucide-react"

interface PageHeaderProps {
  title: string
  description: string
  docLink?: string
}

export function PageHeader({ title, description, docLink }: PageHeaderProps) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-3">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="shrink-0 text-[#7c8189]">
          <rect x="3" y="3" width="18" height="18" rx="3" stroke="currentColor" strokeWidth="1.5" fill="none" />
          <path d="M8 9h8M8 12h8M8 15h5" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
        </svg>
        <h1 className="text-xl font-semibold text-[#e2e8f0]">{title}</h1>
        {docLink && (
          <a
            href="#"
            className="inline-flex items-center gap-1 rounded border border-[#2e3238] px-2 py-0.5 text-[11px] text-[#7c8189] hover:text-[#a1a5ab]"
          >
            Documentation <ExternalLink className="h-3 w-3" />
          </a>
        )}
      </div>
      <p className="mt-1.5 text-sm text-[#7c8189]">{description}</p>
    </div>
  )
}
