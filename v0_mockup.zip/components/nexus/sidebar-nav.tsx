"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

const navItems = [
  { label: "Overview", href: "/" },
  { label: "PQC Readiness", href: "/pqc-readiness" },
  { label: "Certificates", href: "/certificates" },
  { label: "Cryptographic Assets", href: "/cryptographic-assets" },
  { label: "Discovery", href: "/discovery" },
  { label: "Policies", href: "/policies" },
  { label: "Violations", href: "/violations" },
  { label: "Integrations", href: "/integrations" },
  { label: "Audit Logs", href: "/audit-logs" },
  { label: "Settings", href: "/settings" },
]

export function HorizontalNav() {
  const pathname = usePathname()

  return (
    <nav className="flex border-b border-[#2e3238] bg-[#111317] px-4">
      {navItems.map((item) => {
        const isActive =
          item.href === "/"
            ? pathname === "/"
            : pathname.startsWith(item.href)
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`relative px-3 py-2.5 text-[13px] font-medium transition-colors ${
              isActive
                ? "text-[#e2e8f0]"
                : "text-[#7c8189] hover:text-[#a1a5ab]"
            }`}
          >
            {item.label}
            {isActive && (
              <span className="absolute inset-x-0 -bottom-px h-[2px] bg-[#e2e8f0]" />
            )}
          </Link>
        )
      })}
    </nav>
  )
}
