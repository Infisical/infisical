"use client"

import { ChevronRight, ChevronDown, Users, HelpCircle, Bell, User } from "lucide-react"
import Image from "next/image"

export function TopNav() {
  return (
    <div className="z-10 flex min-h-12 items-center bg-[#111317] px-4">
      <div className="mr-auto flex h-full min-w-[8.5rem] items-center">
        {/* Logo */}
        <div className="mt-0.5 shrink-0">
          <Image
            alt="infisical logo"
            src="/images/logotransparent_trimmed.png"
            width={120}
            height={16}
            className="h-4 w-auto"
            priority
          />
        </div>

        <ChevronRight size={18} className="mx-3 mt-[3px] text-[#5c6170]/70" />

        {/* Organization selector - active state with green gradient */}
        <div
          className="relative flex min-w-16 items-center self-end rounded-t-md border-x border-t pt-1.5 pr-2 pb-2.5 pl-3"
          style={{
            borderColor: "rgba(104, 211, 145, 0.15)",
            background: "linear-gradient(to bottom, rgba(104, 211, 145, 0.10), rgba(104, 211, 145, 0.075))",
          }}
        >
          {/* Bottom border hider - matches Infisical's pattern */}
          <div className="absolute -bottom-px left-0 h-px w-full bg-[#111317]">
            <div className="h-full" style={{ background: "rgba(104, 211, 145, 0.075)" }} />
          </div>

          <div className="group mr-1 flex min-w-0 cursor-pointer items-center gap-2 overflow-hidden text-sm text-white transition-all duration-100">
            <button className="flex cursor-pointer items-center gap-x-2 truncate whitespace-nowrap" type="button">
              {/* Org icon */}
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="shrink-0 text-[#68d391]">
                <rect x="1" y="3" width="14" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.2" fill="none" />
                <rect x="4" y="1" width="8" height="4" rx="1" stroke="currentColor" strokeWidth="1.2" fill="none" />
                <rect x="4" y="8" width="3" height="3" rx="0.5" fill="currentColor" />
                <rect x="9" y="8" width="3" height="3" rx="0.5" fill="currentColor" />
              </svg>
              <span className="truncate">Arshwin</span>
              <span className="hidden rounded bg-[#22543d]/80 px-1.5 py-px text-[10px] font-medium text-[#68d391] lg:inline-flex">
                Organization
              </span>
            </button>
          </div>
          <div>
            <button className="px-2 py-1" type="button" aria-label="switch-org">
              <ChevronDown size={11} className="text-[#7c8189]" />
            </button>
          </div>
        </div>

        <ChevronRight size={18} className="mx-3 mt-[3px] text-[#5c6170]/70" />

        {/* Project selector - active state with yellow gradient (new product) */}
        <div
          className="relative flex min-w-16 items-center self-end rounded-t-md border-x border-t pt-1.5 pr-2 pb-2.5 pl-3"
          style={{
            borderColor: "rgba(236, 201, 75, 0.15)",
            background: "linear-gradient(to bottom, rgba(236, 201, 75, 0.10), rgba(236, 201, 75, 0.075))",
          }}
        >
          {/* Bottom border hider */}
          <div className="absolute -bottom-px left-0 h-px w-full bg-[#111317]">
            <div className="h-full" style={{ background: "rgba(236, 201, 75, 0.075)" }} />
          </div>

          <div className="group mr-1 flex min-w-0 cursor-pointer items-center gap-2 overflow-hidden text-sm text-white transition-all duration-100">
            <button className="flex cursor-pointer items-center gap-x-2 truncate whitespace-nowrap" type="button">
              {/* Project gear icon */}
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="shrink-0 text-[#ecc94b]">
                <path d="M8 10a2 2 0 100-4 2 2 0 000 4z" stroke="currentColor" strokeWidth="1.2" fill="none" />
                <path d="M13.3 9.6l.9.5c.2.1.3.4.2.6l-1 1.7c-.1.2-.4.3-.6.2l-.9-.5c-.4.3-.8.5-1.2.7l-.1 1c0 .3-.2.5-.5.5h-2c-.3 0-.5-.2-.5-.5l-.1-1c-.4-.2-.8-.4-1.2-.7l-.9.5c-.2.1-.5 0-.6-.2l-1-1.7c-.1-.2 0-.5.2-.6l.9-.5c-.1-.4-.1-.8 0-1.2l-.9-.5c-.2-.1-.3-.4-.2-.6l1-1.7c.1-.2.4-.3.6-.2l.9.5c.4-.3.8-.5 1.2-.7l.1-1c0-.3.2-.5.5-.5h2c.3 0 .5.2.5.5l.1 1c.4.2.8.4 1.2.7l.9-.5c.2-.1.5 0 .6.2l1 1.7c.1.2 0 .5-.2.6l-.9.5c.1.4.1.8 0 1.2z" stroke="currentColor" strokeWidth="1" fill="none" />
              </svg>
              <span className="truncate">Nexus</span>
              <span className="hidden rounded bg-[#744210]/50 px-1.5 py-px text-[10px] font-medium text-[#ecc94b] lg:inline-flex">
                PQC Threat Intelligence
              </span>
            </button>
          </div>
          <div>
            <button className="px-2 py-1" type="button" aria-label="switch-project">
              <ChevronDown size={11} className="text-[#7c8189]" />
            </button>
          </div>
        </div>
      </div>

      {/* Right side actions */}
      <div className="mt-0.5 mr-3 hidden rounded-sm border border-[#5c6170] px-1 text-xs text-[#cdd1d6] opacity-50 no-underline md:inline-block">
        Enterprise
      </div>

      <a className="mr-2 flex h-[34px] items-center rounded-md border border-[#4b4f58] px-2.5 py-1.5 text-sm whitespace-nowrap text-[#a1a5ab] hover:bg-[#3b3f47]">
        <Users className="inline-block size-3.5" />
        <span className="ml-2 hidden text-[12px] md:inline-block">Invite Users</span>
      </a>

      {/* Help / Notification / User button group */}
      <button className="rounded-l-md border border-r-0 border-[#4b4f58] px-2.5 py-1 text-[#a1a5ab] hover:bg-[#3b3f47]" type="button">
        <HelpCircle className="size-4" />
      </button>
      <div className="relative border-y border-[#4b4f58] px-2.5 py-1 text-[#a1a5ab] hover:bg-[#3b3f47]">
        <Bell className="size-4" />
        <span className="absolute -top-1.5 -right-1.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-[#ecc94b] px-1 text-[9px] font-bold text-black">
          39
        </span>
      </div>
      <button className="rounded-r-md border border-l-0 border-[#4b4f58] px-2.5 py-1 text-[#a1a5ab] hover:bg-[#3b3f47]" type="button">
        <User className="size-4" />
      </button>
    </div>
  )
}
